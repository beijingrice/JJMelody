//
//  Note.swift
//  iOS_Game_Develop_Learning
//
//  Created by Rice on 2021/5/8.
//

import SpriteKit

class Note: SKShapeNode {
    var duration : Int = 0
}
