//
//  GameScene.swift
//  iOS_Game_Develop_Learning
//
//  Created by Rice on 2021/5/7.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var total : Int = 200 - 1
    
    var note_durations = [3, 5, 2, 3, 1, 1, 1, 3, 4, 1, 2, 4, 3, 2, 3, 4, 4, 3, 2, 2, 4, 5, 1, 1, 3, 3, 5, 3, 2, 3, 5, 3, 2, 3, 2, 1, 1, 5, 3, 2, 5, 1, 4, 5, 1, 5, 5, 5, 3, 1, 5, 5, 4, 1, 5, 3, 2, 4, 5, 2, 1, 4, 1, 1, 1, 3, 1, 2, 1, 1, 3, 4, 3, 2, 2, 3, 1, 2, 4, 4, 5, 5, 1, 3, 2, 5, 5, 2, 4, 3, 5, 5, 4, 5, 4, 4, 1, 1, 1, 5, 4, 2, 3, 4, 5, 4, 2, 1, 3, 4, 4, 4, 3, 1, 2, 1, 3, 4, 3, 3, 1, 1, 3, 5, 4, 4, 1, 5, 4, 3, 4, 3, 1, 4, 4, 4, 5, 2, 1, 2, 4, 2, 1, 3, 2, 4, 1, 5, 2, 5, 3, 3, 2, 4, 1, 2, 2, 4, 3, 2, 2, 2, 3, 3, 3, 1, 5, 2, 4, 5, 2, 1, 2, 2, 5, 4, 2, 4, 5, 2, 1, 4, 5, 3, 2, 5, 5, 1, 2, 2, 1, 3, 4, 2, 3, 1, 5, 4, 3, 5]
    
    private var lastUpdateTime : TimeInterval = 0
    var entities = [GKEntity]()
    var r = [191, 231, 158, 178, 68, 242, 70, 59, 48, 251, 176, 105, 104, 5, 101, 152, 77, 84, 12, 31, 78, 159, 179, 165, 174, 134, 179, 244, 201, 160, 197, 229, 239, 234, 82, 106, 66, 239, 238, 192, 59, 206, 3, 29, 23, 176, 79, 85, 20, 184, 65, 222, 55, 197, 240, 74, 234, 49, 94, 128, 1, 37, 47, 85, 177, 116, 166, 57, 230, 220, 199, 214, 52, 8, 53, 31, 211, 158, 73, 221, 149, 51, 7, 98, 143, 173, 1, 170, 105, 149, 171, 52, 137, 88, 28, 62, 133, 163, 37, 207, 118, 115, 251, 160, 123, 62, 155, 248, 92, 164, 19, 248, 66, 142, 245, 136, 145, 146, 173, 84, 37, 81, 248, 24, 42, 83, 134, 170, 129, 112, 53, 143, 249, 185, 224, 144, 120, 102, 57, 113, 8, 124, 35, 39, 97, 248, 5, 8, 88, 190, 139, 82, 186, 235, 25, 245, 25, 26, 165, 221, 231, 245, 209, 33, 170, 249, 168, 48, 107, 46, 100, 119, 138, 189, 109, 109, 171, 172, 80, 226, 52, 94, 17, 140, 18, 75, 171, 34, 147, 190, 196, 93, 23, 75, 210, 46, 109, 20, 140, 234]
    var g = [161, 60, 80, 15, 163, 210, 12, 119, 145, 17, 193, 117, 226, 219, 96, 162, 243, 171, 71, 103, 156, 59, 228, 72, 29, 219, 9, 154, 83, 21, 79, 54, 184, 189, 208, 154, 167, 249, 108, 149, 230, 240, 126, 141, 63, 90, 246, 236, 113, 220, 254, 66, 230, 3, 47, 173, 227, 34, 96, 10, 128, 88, 157, 32, 121, 95, 100, 176, 78, 9, 56, 81, 241, 62, 175, 48, 167, 223, 195, 230, 9, 74, 192, 189, 121, 30, 29, 15, 208, 175, 180, 102, 168, 149, 138, 44, 173, 1, 217, 98, 229, 172, 55, 180, 196, 24, 23, 245, 57, 193, 3, 94, 4, 148, 121, 87, 189, 84, 34, 196, 84, 6, 116, 144, 58, 247, 113, 154, 152, 201, 102, 197, 34, 180, 212, 80, 144, 85, 96, 114, 106, 135, 177, 38, 96, 137, 219, 14, 143, 5, 241, 131, 177, 76, 57, 242, 72, 235, 21, 20, 128, 17, 60, 105, 237, 168, 201, 40, 188, 222, 155, 174, 147, 153, 186, 110, 213, 64, 62, 125, 7, 57, 206, 194, 112, 89, 76, 179, 71, 37, 196, 86, 210, 108, 182, 15, 201, 231, 226, 212]
    var b = [176, 53, 120, 147, 16, 213, 217, 77, 163, 138, 223, 157, 111, 26, 124, 80, 218, 34, 54, 149, 225, 236, 84, 206, 1, 177, 212, 249, 233, 44, 195, 57, 232, 59, 169, 57, 124, 156, 108, 183, 188, 134, 31, 201, 78, 183, 38, 93, 224, 188, 203, 129, 40, 23, 38, 145, 26, 26, 225, 190, 140, 19, 147, 123, 88, 69, 79, 14, 148, 75, 99, 16, 91, 102, 190, 186, 47, 185, 242, 52, 102, 182, 218, 11, 33, 148, 25, 77, 195, 55, 149, 14, 36, 7, 140, 71, 7, 184, 202, 126, 34, 245, 106, 195, 95, 220, 46, 180, 193, 198, 84, 99, 132, 181, 1, 115, 109, 225, 150, 206, 205, 52, 66, 196, 46, 8, 210, 119, 118, 64, 84, 193, 172, 23, 103, 165, 240, 49, 242, 161, 128, 83, 200, 77, 38, 172, 178, 207, 232, 204, 153, 50, 156, 35, 251, 251, 220, 122, 30, 191, 254, 91, 15, 68, 59, 91, 73, 153, 66, 13, 50, 191, 102, 22, 223, 7, 254, 155, 96, 121, 6, 138, 181, 15, 171, 156, 11, 156, 209, 196, 175, 224, 239, 71, 98, 191, 77, 31, 25, 205]
    var colors : [SKColor] = []
    var checkList : [Bool] = []
    
    
    
    
    // FOR DEBUG
    
    // FOR DEBUG
    
    var notes = [SKShapeNode]()
    
    let miss = SKLabelNode(fontNamed: "Chalkduster")
    let meh = SKLabelNode(fontNamed: "Chalkduster")
    let good = SKLabelNode(fontNamed: "Chalkduster")
    let perfect = SKLabelNode(fontNamed: "Chalkduster")
    let excellent = SKLabelNode(fontNamed: "Chalkduster")
    
    var width = 93.75
    var note_x = [46.875, 140.625, 234.375, 328.125]
    
    
    func initArrays(total total : Int) {
        arc4random()
    }
    
    
    override func didMove(to view: SKView) {
        anchorPoint = CGPoint.zero
        
    }

    override func sceneDidLoad() {
        
        for x in 0...total {
            colors.append(SKColor.init(red: CGFloat(r[x]), green: CGFloat(g[x]), blue: CGFloat(b[x]), alpha: 100))
        }
        
        for _ in 0...total {
            checkList.append(false)
        }
        
        
        
        
        
        
        
        miss.fontSize = allFontSize
        meh.fontSize = allFontSize
        good.fontSize = allFontSize
        perfect.fontSize = allFontSize
        excellent.fontSize = allFontSize
        miss.text = "Miss!"
        meh.text = "Meh"
        good.text = "Good"
        perfect.text = "Perfect"
        excellent.text = "Excellent!"
        miss.fontColor = SKColor.red
        meh.fontColor = SKColor.init(red: 200, green: 50, blue: 50, alpha: 0)
        perfect.fontColor = SKColor.blue
        excellent.fontColor = SKColor.green
        good.fontColor = SKColor.green
        
        for x in 0...total {
            // notes.append(Note(rectOf: CGSize(width: width, height: note_durations[x] * 100)))
            
            notes.append(Note(rectOf: CGSize(width: CGFloat(width), height: CGFloat(note_durations[x] * 100))))
            
            let color = colors[x]
            notes[x].fillColor = color as! UIColor
            notes[x].strokeColor = color as! UIColor
            notes[x].position = CGPoint(x: CGFloat(note_x[x % 4]), y: self.frame.maxY + 300)
        }
        
        
        // var move = SKAction.moveTo(y: 200, duration: 2)
        
        
        let queue = DispatchQueue.global(priority:DispatchQueue.GlobalQueuePriority.default)
        queue.async() {
            while (true) {
                self.checkIfGetout()
                sleep(UInt32(0.5))
            }
        }
        let loadBlocks = DispatchQueue.global(priority:DispatchQueue.GlobalQueuePriority.default)
        var steps = [3, 4, 3, 2, 3, 3, 4, 2, 3, 4, 2, 3, 4, 3]
        var index : Int = 0
        
        var abort : Bool = false
        
        var debugValue : Int = 0
        
        loadBlocks.async {
            for step in steps {
                if abort {
                    break
                }
                for x in index...index + step + debugValue{
                    if x <= self.total {
                        self.addChild(self.notes[x])
                        let moveAction = SKAction.moveTo(y: self.frame.minY - CGFloat(self.note_durations[x] * 100), duration: 5)
                        self.notes[x].run(moveAction)
                        // sleep(UInt32(arc4random_uniform(300)) / 100)
                    } else {
                        if x > self.total {
                            break
                            abort = true
                        }
                    }
                }
                index = index + step + 1 + debugValue
            sleep(3)
            }
            
        }
    }
    
    
    
    var click_begin : CGFloat = 0
    var click_end : CGFloat = 0
    var click_x_pos : CGFloat = 0
    
    var startClickDeviation = 23333
    var endClickDeviation = 23333
    
    
    func touchDown(atPoint pos : CGPoint) {
        click_x_pos = pos.x
        if getDeviation(click_y: pos.y, mode: true) != 23333 {
            startClickDeviation = getDeviation(click_y: pos.y, mode: true)
        }
        showLevelMsg(deviation: startClickDeviation)
    }
    
    
    
    func checkIfGetout() {
        for x in 0...total {
            if notes[x].position.y + CGFloat(note_durations[x] * 100 / 2) < 0 {
                if !checkList[x] {
                    showUpTextUndepend(level: "Miss")
                    checkList[x] = true
                }
            }
        }
    }
    
    var judge_line_y : CGFloat = 50
    
    public var track1 : [Int] = []
    public var track2 : [Int] = []
    public var track3 : [Int] = []
    public var track4 : [Int] = []
    
    var tempRectX : CGFloat = 0
    
    var currentRectsOnScreen: [Int] = []
    
    func doNothing() {}
    
    var op_t : [Int] = []
    
    func updateTrack(theli track : [Int], current_x the_x : Int, the_track_num the_track_num : Int) -> ([Int], Bool, Int) {
        var track = track
        if the_track_num == 1 {
            track = track1
            // Do operations to the array
            for each in track1 { // Remove the element if it doesn't exist on the screen
                if !currentRectsOnScreen.contains(each) {
                    track1.remove(at: track1.firstIndex(of: each)!)
                }
            }
            if !track1.contains(the_x) { // Update the track (if new element doesn't exist in current array, append.)
                track1.append(the_x)
            }
        }
        if the_track_num == 2 {
            track = track2
            // Do operations to the array
            for each in track2 { // Remove the element if it doesn't exist on the screen
                if !currentRectsOnScreen.contains(each) {
                    track2.remove(at: track2.firstIndex(of: each)!)
                }
            }
            if !track2.contains(the_x) { // Update the track (if new element doesn't exist in current array, append.)
                track2.append(the_x)
            }
        }
        if the_track_num == 3 {
            track = track3
            // Do operations to the array
            for each in track3 { // Remove the element if it doesn't exist on the screen
                if !currentRectsOnScreen.contains(each) {
                    track3.remove(at: track3.firstIndex(of: each)!)
                }
            }
            if !track3.contains(the_x) { // Update the track (if new element doesn't exist in current array, append.)
                track3.append(the_x)
            }
        }
        if the_track_num == 4 {
            track = track4
            // Do operations to the array
            for each in track4 { // Remove the element if it doesn't exist on the screen
                if !currentRectsOnScreen.contains(each) {
                    track4.remove(at: track4.firstIndex(of: each)!)
                }
            }
            if !track4.contains(the_x) { // Update the track (if new element doesn't exist in current array, append.)
                track4.append(the_x)
            }
        }
        
        // Analysis the block which the closest to judge line
        if track.count > 1 { // length larger than 1, return the one close to bottom (judge line)
            var currentMininumX : CGFloat = notes[track[0]].position.x
            var currentMininumIndex : Int = track[0]
            for each in track {
                if notes[each].position.x < currentMininumX {
                    currentMininumX = notes[each].position.x
                    currentMininumIndex = each
                }
            }
            """
            print("multi")
            print()
            print(track, currentMininumIndex)
            print()
            """
            return (track, true, currentMininumIndex)
        }
        if track.count == 1 {
            """
            print("single")
            print()
            print(track, track[0])
            print()
            """
            return (track, false, track[0])
        }
        return (track, false, track[0])
    }
    
    func getDeviation(click_y y : CGFloat, mode m : Bool) -> Int {
        
        // var debug : Bool = true
        // var origin : SKColor = SKColor.white
        
        currentRectsOnScreen = []
        
        var the_rect_to_judge = 0
        
        var Deviation : Int = 0
        for x in 0...total {
            if notes[x].position.x - (CGFloat(width) / 2) <= click_x_pos && click_x_pos <= notes[x].position.x + (CGFloat(width) / 2) { // judge track
                currentRectsOnScreen.append(x)
                tempRectX = notes[x].position.x
                if 0 <= tempRectX && CGFloat(width) > click_x_pos {
                    the_rect_to_judge = updateTrack(theli: track1, current_x: x, the_track_num: 1).2
                } else if CGFloat(width) <= click_x_pos && CGFloat(width * 2) > click_x_pos {
                    the_rect_to_judge = updateTrack(theli: track2, current_x: x, the_track_num: 2).2
                } else if CGFloat(width * 2) <= click_x_pos && CGFloat(width * 3) > click_x_pos {
                    the_rect_to_judge = updateTrack(theli: track3, current_x: x, the_track_num: 3).2
                } else if CGFloat(width * 3) <= click_x_pos && CGFloat(width * 4) > click_x_pos {
                    the_rect_to_judge = updateTrack(theli: track4, current_x: x, the_track_num: 4).2
                }
                
                if (notes[the_rect_to_judge].position.y + CGFloat(note_durations[the_rect_to_judge] * 100 / 2) >= 0) && (notes[the_rect_to_judge].position.y - CGFloat((note_durations[the_rect_to_judge] * 100 / 2)) <= frame.maxY) { // judge y and accruancy
                    
                    notes[the_rect_to_judge].strokeColor = SKColor.white
                    
                    checkList[x] = true
                    if m { // start
                        Deviation = Int(abs(y - (notes[x].position.y - CGFloat((note_durations[x] * 100 / 2)))))
                    } else { // end
                        Deviation = Int(abs(y - (notes[x].position.y + CGFloat((note_durations[x] * 100 / 2)))))
                    }
                }
            }
        }
        return Deviation
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    var fadeAnimationDuration = 1
    
    // let moveAction = SKAction.moveTo(y: self.frame.minY - CGFloat(note_durations[x] * 100), duration: 10)
    // moveAction.timingMode = SKActionTimingMode.easeInEaseOut
    
    var allFontSize : CGFloat = 30
    
    
    func showUpTextUndepend(level level : String) {
        var thePosition : CGPoint = CGPoint(x: frame.maxX / 2, y: frame.maxY / 2)
        var fadeAnimation = SKAction.fadeOut(withDuration: TimeInterval(fadeAnimationDuration))
        switch level {
        case "Excellent":
            let excellent = SKLabelNode(fontNamed: "Chalkduster")
            excellent.fontSize = self.allFontSize
            excellent.text = "Excellent!"
            excellent.fontColor = SKColor.systemBlue
            excellent.run(fadeAnimation)
            excellent.position = thePosition
            addChild(excellent)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                excellent.removeFromParent()
            }
        case "Perfect":
            let perfect = SKLabelNode(fontNamed: "Chalkduster")
            perfect.fontSize = self.allFontSize
            perfect.text = "Perfect!"
            perfect.fontColor = SKColor.blue
            perfect.run(fadeAnimation)
            perfect.position = thePosition
            addChild(perfect)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                perfect.removeFromParent()
            }
        case "Good":
            let good = SKLabelNode(fontNamed: "Chalkduster")
            good.fontSize = self.allFontSize
            good.text = "Good!"
            good.fontColor = SKColor.green
            good.run(fadeAnimation)
            good.position = thePosition
            addChild(good)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                good.removeFromParent()
            }
        case "Meh":
            let meh = SKLabelNode(fontNamed: "Chalkduster")
            meh.fontSize = self.allFontSize
            meh.text = "Meh!"
            meh.fontColor = SKColor.yellow
            meh.run(fadeAnimation)
            meh.position = thePosition
            addChild(meh)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                meh.removeFromParent()
            }
        case "Miss":
            let miss = SKLabelNode(fontNamed: "Chalkduster")
            miss.fontSize = self.allFontSize
            miss.text = "Miss"
            miss.fontColor = SKColor.red
            miss.run(fadeAnimation)
            miss.position = thePosition
            addChild(miss)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                miss.removeFromParent()
            }
        default:
            return
        }
    }
    
    func showLevelMsg(deviation deviation : Int) {
        if deviation <= 15 {
            showUpTextUndepend(level: "Excellent")
        }
        if deviation > 15 && deviation <= 30 {
            showUpTextUndepend(level: "Perfect")
        }
        if deviation > 30 && deviation <= 40 {
            showUpTextUndepend(level: "Good")
        }
        if deviation > 40 && deviation <= 50 {
            showUpTextUndepend(level: "Meh")
        }
        if deviation > 50 {
            showUpTextUndepend(level: "Miss")
        }
    }
    
    
    func touchUp(atPoint pos : CGPoint) {
        click_end = pos.y
        click_x_pos = pos.x
        
        // DEBUG USAGE
        // var pos_rect = Note(rectOf: CGSize(width: 200, height: 200))
        // pos_rect.position = CGPoint(x: pos.x, y: pos.y)
        // addChild(pos_rect)
        // DEBUG USAGE
        
        if getDeviation(click_y: pos.y, mode: false) != 23333 {
            endClickDeviation = getDeviation(click_y: pos.y, mode: false)
        }
        showLevelMsg(deviation: endClickDeviation)

        }
        // judge here
        
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchDown(atPoint: t.location(in: self))
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchUp(atPoint: t.location(in: self))
        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        
        
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime
    }
}
